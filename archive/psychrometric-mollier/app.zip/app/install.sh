#!/usr/bin/env bash
# SensorHub one-shot setup. Run from inside the sensor-hub/ folder:  bash install.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

echo "==> Creating virtualenv (.venv)"
python3 -m venv .venv

echo "==> Installing Python dependencies"
.venv/bin/pip install --upgrade pip >/dev/null
.venv/bin/pip install -r requirements.txt

# On a Raspberry Pi, also install GPIO support (harmless failure elsewhere).
if grep -qi "raspberry pi" /proc/device-tree/model 2>/dev/null; then
  echo "==> Raspberry Pi detected — installing GPIO libraries"
  .venv/bin/pip install gpiozero lgpio || echo "   (gpiozero install skipped)"
fi

echo
echo "==> Done. Start the hub with:"
echo "      .venv/bin/python -m backend"
echo "   then open  http://<this-machine-ip>:8000/  in any browser."
echo
echo "   To run it automatically on boot (Pi/Linux), edit paths in"
echo "   sensor-hub.service to match this folder, then:"
echo "      sudo cp sensor-hub.service /etc/systemd/system/"
echo "      sudo systemctl daemon-reload && sudo systemctl enable --now sensor-hub"
