"""Example HTTP sensor/actuator node (evolution of the original app.py).

Run this ON a device with sensors (e.g. a second Pi, or the same Pi) to expose:
  GET  /api/led   -> {"tdb":.., "w":.., "led":0/1, "timestamp":..}
  POST /api/led   -> body {"action":"on"|"off"|"toggle"} or {"value":0|1}; controls the LED

Then in SensorHub:
  • add an HTTP sensor pointing at http://<node-ip>:5000/api/led (map tdb->tdb, w->W? here it's 'w')
  • add an HTTP actuator pointing at the same URL to switch the LED on/off.

Pure standard-library HTTP server so it runs anywhere; GPIO is used only if
gpiozero is installed (real Pi), otherwise the LED is simulated in memory.
"""
from __future__ import annotations

import json
import math
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

# Optional real LED on BCM pin 17; falls back to a simulated flag off-Pi.
try:
    from gpiozero import LED
    _led = LED(17)
    def led_set(on): _led.on() if on else _led.off()
    def led_get(): return int(_led.value)
except Exception:  # noqa: BLE001
    _state = {"on": 0}
    def led_set(on): _state["on"] = 1 if on else 0
    def led_get(): return _state["on"]


def climate():
    frac = (time.time() % 86400) / 86400.0
    tdb = 24 + 6 * math.sin(2 * math.pi * frac)
    rh = max(30.0, 70.0 - 1.5 * (tdb - 24))
    pws = 610.94 * math.exp((17.625 * tdb) / (tdb + 243.04))
    pw = (rh / 100.0) * pws
    w = 0.621945 * pw / (101325 - pw)
    return round(tdb, 2), round(w, 5)


class Handler(BaseHTTPRequestHandler):
    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")  # CORS for browsers
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.startswith("/api/led"):
            tdb, w = climate()
            self._json({"tdb": tdb, "w": w, "led": led_get(),
                        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S")})
        else:
            self._json({"endpoint": "/api/led", "status": "online"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        try:
            payload = json.loads(self.rfile.read(n) or b"{}")
        except json.JSONDecodeError:
            payload = {}
        if "value" in payload:
            led_set(bool(payload["value"]))
        else:
            action = str(payload.get("action", "")).lower()
            led_set(True if action == "on" else False if action == "off"
                    else not led_get() if action == "toggle" else led_get())
        self._json({"led": led_get()})

    def log_message(self, *a):  # quieter console
        pass


if __name__ == "__main__":
    print("Example node on http://0.0.0.0:5000/api/led  (Ctrl+C to stop)")
    HTTPServer(("0.0.0.0", 5000), Handler).serve_forever()
