# SensorHub

Gateway + dashboard lintas-OS untuk sensor greenhouse (dan lainnya): **baca banyak
sensor, simpan & kelola data, teruskan ke tujuan lain, cek status, dan kontrol
perangkat** — semua dari satu halaman web.

Ini **satu program Python** yang kamu jalankan di satu mesin yang selalu-nyala
(Raspberry Pi paling cocok). Program itu menyajikan dashboard web. Untuk membukanya
di **Windows / Ubuntu / Pi / HP / OS apa pun**, cukup buka browser ke
`http://<ip-mesin-hub>:8000/` — **tanpa instalasi apa pun di perangkat lain**.

---

## Cara cepat menjalankan

```bash
cd sensor-hub
bash install.sh                 # buat venv + install dependensi
.venv/bin/python -m backend     # jalankan hub
```
Lalu buka `http://localhost:8000/` (atau `http://<ip-mesin>:8000/` dari perangkat lain).

> Windows: `python -m venv .venv` lalu `.venv\Scripts\python -m backend`.

Halaman API interaktif (untuk cek/kontrol manual) tersedia di `http://<ip>:8000/docs`.

---

## Isi dashboard (tab)

| Tab | Fungsi |
|-----|--------|
| **Live** | Nilai real-time tiap sensor + status, update instan via WebSocket. |
| **Sensors** | Tambah/ubah/hapus sumber sensor. Tipe: HTTP (URL apa pun ber-JSON) atau Pi hardware (GPIO/DHT22/DS18B20). Ada tombol **Test read**. |
| **Data** | Query, grafik, tabel, **export CSV**, dan hapus data tersimpan. |
| **Control** | Aktuator — kirim perintah ke perangkat (GPIO Pi atau node HTTP). Toggle on/off. |
| **Forwarding** | Teruskan tiap pembacaan ke **webhook (URL:port)** atau **MQTT**, dan lihat URL **pull-API** yang bisa dibaca app lain. |
| **Status** | Kesehatan sistem: platform, uptime, CPU/RAM/suhu (di Pi), ukuran DB, log kejadian. |
| **Settings** | Origin CORS & lama retensi data. |

---

## Menghubungkan sensor

- **HTTP** — sumber apa pun yang membalas JSON. Contoh: node Pi di
  `http://192.168.0.100:5000/api/led` yang membalas `{"tdb":..,"W":..}`. Di form,
  petakan metric → field JSON (mis. `tdb`→`tdb`, `w`→`W`). Dot-path didukung (`data.temp`).
- **Hardware Pi** — `gpio_digital`, `dht22`, `ds18b20`. Hanya aktif saat hub jalan di Pi
  (di PC otomatis ditandai "Pi-only"). Butuh library tambahan di Pi (lihat komentar di driver).

Menambah tipe sensor baru = tambahkan satu file di `backend/drivers/` (lihat `http.py`
sebagai contoh) dan daftarkan di `drivers/__init__.py`.

---

## Menghubungkan ke PsychroMol (memperbaiki error CORS)

Hub mengekspos data bersih ber-CORS di:
```
http://<ip-hub>:8000/api/sensors/<id>/latest   ->  {"tdb":.., "w":.., "rh":.., "timestamp":..}
```
Di tab **Sensor** PsychroMol, isi *Data URL* dengan alamat itu, `Tdb field = tdb`,
`W field = w`. Karena hub mengirim header `Access-Control-Allow-Origin`, browser tidak
lagi memblokirnya (itulah error yang dulu muncul).

---

## Meneruskan data keluar (Forwarding)

- **Webhook** — hub otomatis `POST {sensor, ts, metrics}` ke URL:port pilihanmu setiap
  ada pembacaan baru (mis. ke Node-RED, Google Sheet via Apps Script, dll).
- **MQTT** — publish JSON ke broker/topic (mis. `test.mosquitto.org:1883`).
- **Pull-API** — selalu aktif; app lain menarik data sendiri dari URL di atas.

---

## Jalan otomatis saat boot (Pi/Linux)

```bash
# sesuaikan User & path di sensor-hub.service dulu
sudo cp sensor-hub.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now sensor-hub
sudo systemctl status sensor-hub      # cek jalan
journalctl -u sensor-hub -f           # lihat log langsung
```

---

## Struktur

```
sensor-hub/
  backend/            # FastAPI app + logika
    main.py           # REST API + WebSocket + serve dashboard
    db.py             # SQLite (sensors, readings, actuators, forwards, events)
    sensors.py        # CRUD + polling
    drivers/          # tipe sensor (http, gpio_digital, dht22, ds18b20)
    actuators.py      # kontrol (gpio_out, http)
    forwarding.py     # webhook + MQTT
    scheduler.py      # polling terjadwal + retensi
    status.py         # status sistem
  web/                # dashboard (HTML/CSS/JS, tanpa build)
  examples/http-node.py   # contoh node sensor/aktuator HTTP
  requirements.txt  install.sh  sensor-hub.service
```

Data disimpan di `sensor-hub/data/sensorhub.db` (SQLite). Aman dihapus untuk mulai bersih.
