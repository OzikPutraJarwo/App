"use strict";
/* SensorHub dashboard — vanilla JS, no build step, no external libraries. */

// ── API ─────────────────────────────────────────────────────────────────
const API = {
  async get(p) { return (await fetch(p)).json(); },
  async send(p, method, body) {
    const r = await fetch(p, { method, headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail || r.statusText);
    return r.status === 204 ? null : r.json();
  },
  post(p, b) { return this.send(p, "POST", b); },
  patch(p, b) { return this.send(p, "PATCH", b); },
  del(p) { return this.send(p, "DELETE"); },
};

// ── Utilities ────────────────────────────────────────────────────────────
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtNum = (v) => (typeof v === "number" ? (Math.abs(v) < 1 && v !== 0 ? v.toFixed(4) : v.toFixed(2)) : v);
const ago = (ts) => {
  if (!ts) return "never";
  const s = Math.round(Date.now() / 1000 - ts);
  if (s < 5) return "just now";
  if (s < 60) return s + "s ago";
  if (s < 3600) return Math.round(s / 60) + "m ago";
  return Math.round(s / 3600) + "h ago";
};
function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove("show"), 2600);
}
function openModal(html) { $("#modal").innerHTML = html; $("#overlay").classList.add("open"); }
function closeModal() { $("#overlay").classList.remove("open"); }
$("#overlay").addEventListener("click", (e) => { if (e.target.id === "overlay") closeModal(); });

const ICONS = {
  plus: 'M12 5v14M5 12h14',
  edit: 'M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7|M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z',
  trash: 'M3 6h18|M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4|M7 10l5 5 5-5|M12 15V3',
};
function ic(name, cls = "ic ic-sm") {
  const paths = ICONS[name].split("|").map((d) => `<path d="${d}"/>`).join("");
  return `<svg viewBox="0 0 24 24" class="${cls}">${paths}</svg>`;
}

// ── State ─────────────────────────────────────────────────────────────────
let DRIVERS = [];
let SENSORS = [];
const liveBuffers = {};   // sensorId -> { metric: [values] }
const BUF = 60;
const dataState = { sid: null, metric: null, since: 0, points: [] };

// ── Nav routing ────────────────────────────────────────────────────────────
$("#nav").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-tab]"); if (!btn) return;
  const tab = btn.dataset.tab;
  $$("#nav button").forEach((b) => b.classList.toggle("active", b === btn));
  $$("main .tab").forEach((s) => s.classList.toggle("active", s.dataset.tab === tab));
  refreshTab(tab);
});
function refreshTab(tab) {
  ({ live: loadLive, sensors: loadSensors, data: loadDataTab, control: loadControl,
     forwarding: loadForwarding, status: loadStatus, settings: loadSettings }[tab] || (() => {}))();
}
function activeTab() { return $("main .tab.active")?.dataset.tab; }

// ── WebSocket live feed ────────────────────────────────────────────────────
function connectWS() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws`);
  ws.onopen = () => { $("#conn-dot").className = "dot live"; $("#conn-text").textContent = "live"; };
  ws.onclose = () => {
    $("#conn-dot").className = "dot dead"; $("#conn-text").textContent = "reconnecting…";
    setTimeout(connectWS, 2000);
  };
  ws.onmessage = (ev) => handleLive(JSON.parse(ev.data));
}
function handleLive(msg) {
  if (msg.type === "reading") {
    const buf = liveBuffers[msg.sensor_id] || (liveBuffers[msg.sensor_id] = {});
    for (const [m, v] of Object.entries(msg.metrics)) {
      (buf[m] || (buf[m] = [])).push(v);
      if (buf[m].length > BUF) buf[m].shift();
    }
    if (activeTab() === "live") updateLiveCard(msg.sensor_id, msg.metrics);
    if (activeTab() === "data") appendLiveData(msg);
  } else if (msg.type === "sensor_status") {
    const pill = $(`#live-${msg.sensor_id} .pill`);
    if (pill) { pill.className = "pill " + msg.status; pill.textContent = msg.status; }
  } else if (msg.type === "actuator_state" && activeTab() === "control") {
    loadControl();
  }
}

// ── LIVE tab ────────────────────────────────────────────────────────────────
async function loadLive() {
  SENSORS = await API.get("/api/sensors");
  const grid = $("#live-grid");
  if (!SENSORS.length) { grid.innerHTML = emptyState("No sensors yet", "Add one in the Sensors tab to see live data."); return; }
  grid.innerHTML = SENSORS.map(liveCardHTML).join("");
  SENSORS.forEach((s) => {
    const m = s.latest?.metrics || {};
    for (const [k, v] of Object.entries(m)) (liveBuffers[s.id] || (liveBuffers[s.id] = {}))[k] ??= [v];
    drawSpark(s.id);
  });
}
function liveCardHTML(s) {
  const m = s.latest?.metrics || {};
  const metrics = Object.entries(m).map(([k, v]) =>
    `<div class="metric"><span class="v" data-m="${esc(k)}">${fmtNum(v)}</span><span class="k">${esc(k)}</span></div>`).join("")
    || `<span class="muted" style="font-size:13px">waiting for first reading…</span>`;
  return `<div class="card" id="live-${s.id}">
    <div class="card-head"><h3>${esc(s.name)}</h3><span class="pill ${s.status}">${s.status}</span></div>
    <div class="sub">${esc(s.driver)} · <span class="upd">${ago(s.latest?.ts)}</span></div>
    <div class="metrics">${metrics}</div>
    <canvas class="spark" id="spark-${s.id}"></canvas></div>`;
}
function updateLiveCard(id, metrics) {
  const card = $(`#live-${id}`); if (!card) { loadLive(); return; }
  const box = $(".metrics", card), pill = $(".pill", card);
  if (pill) { pill.className = "pill online"; pill.textContent = "online"; }
  $(".upd", card).textContent = "just now";
  const have = {}; $$(".metric .v", box).forEach((el) => have[el.dataset.m] = el);
  for (const [k, v] of Object.entries(metrics)) {
    if (have[k]) have[k].textContent = fmtNum(v);
    else box.insertAdjacentHTML("beforeend",
      `<div class="metric"><span class="v" data-m="${esc(k)}">${fmtNum(v)}</span><span class="k">${esc(k)}</span></div>`);
  }
  drawSpark(id);
}

// ── SENSORS tab ─────────────────────────────────────────────────────────────
async function loadSensors() {
  SENSORS = await API.get("/api/sensors");
  $("#sensors-body").innerHTML = SENSORS.map((s) => {
    const m = s.latest?.metrics || {};
    const latest = Object.entries(m).map(([k, v]) => `${esc(k)}=${fmtNum(v)}`).join(", ") || "—";
    return `<tr>
      <td><b>${esc(s.name)}</b></td><td>${esc(s.driver)}</td><td>${s.interval_sec}s</td>
      <td><span class="pill ${s.status}">${s.status}</span>${s.last_error ? `<div class="muted" style="font-size:11px;white-space:normal;max-width:220px">${esc(s.last_error)}</div>` : ""}</td>
      <td class="muted wrap">${esc(latest)}</td>
      <td><div class="actions">
        <button class="btn icon small" title="Edit" onclick="openSensorModal(${s.id})">${ic("edit")}</button>
        <button class="btn icon small danger" title="Delete" onclick="delSensor(${s.id})">${ic("trash")}</button>
      </div></td></tr>`;
  }).join("") || `<tr><td colspan="6" class="empty">No sensors yet.</td></tr>`;
}
async function delSensor(id) {
  if (!confirm("Delete this sensor? Its stored data is kept.")) return;
  await API.del(`/api/sensors/${id}`); toast("Sensor deleted"); loadSensors();
}
function driverFieldsHTML(driver, cfg = {}) {
  const d = DRIVERS.find((x) => x.key === driver); if (!d) return "";
  return d.fields.map((f) => {
    const val = cfg[f.name] ?? f.default ?? "";
    if (f.type === "bool")
      return `<div class="field"><label>${esc(f.label)}</label>
        <select data-cfg="${f.name}"><option value="false"${!val ? " selected" : ""}>No</option><option value="true"${val ? " selected" : ""}>Yes</option></select></div>`;
    if (f.type === "keymap") {
      const rows = Object.entries(val && typeof val === "object" ? val : { "": "" });
      return `<div class="field"><label>${esc(f.label)} <span class="muted">— metric name → JSON field</span></label>
        <div id="keymap">${rows.map(keymapRow).join("")}</div>
        <button type="button" class="btn small" onclick="addKeymapRow()">${ic("plus")} field</button></div>`;
    }
    const type = f.type === "number" ? "number" : "text";
    return `<div class="field"><label>${esc(f.label)}${f.required ? " *" : ""}</label>
      <input data-cfg="${f.name}" type="${type}" value="${esc(val)}" placeholder="${esc(f.placeholder || "")}"></div>`;
  }).join("");
}
function keymapRow(entry = ["", ""]) {
  return `<div class="keymap-row"><input class="km-k" placeholder="tdb" value="${esc(entry[0])}">
    <input class="km-v" placeholder="tdb" value="${esc(entry[1])}">
    <button type="button" class="btn icon small danger" onclick="this.parentElement.remove()">${ic("trash")}</button></div>`;
}
function addKeymapRow() { $("#keymap").insertAdjacentHTML("beforeend", keymapRow()); }
function collectConfig() {
  const cfg = {};
  $$("[data-cfg]").forEach((el) => {
    let v = el.value;
    if (el.tagName === "SELECT" && (v === "true" || v === "false")) v = v === "true";
    else if (el.type === "number") v = v === "" ? undefined : Number(v);
    if (v !== "" && v !== undefined) cfg[el.dataset.cfg] = v;
  });
  const km = $("#keymap");
  if (km) {
    const map = {};
    $$(".keymap-row", km).forEach((r) => { const k = $(".km-k", r).value.trim(); if (k) map[k] = $(".km-v", r).value.trim(); });
    cfg.fields = map;
  }
  return cfg;
}
async function openSensorModal(id = null) {
  if (!DRIVERS.length) DRIVERS = await API.get("/api/drivers");
  const firstAvail = (DRIVERS.find((d) => d.available) || DRIVERS[0] || {}).key || "http";
  const s = id ? await API.get(`/api/sensors/${id}`) : { name: "", driver: firstAvail, config: {}, interval_sec: 5 };
  const opts = DRIVERS.map((d) => `<option value="${d.key}"${d.key === s.driver ? " selected" : ""}${d.available ? "" : " disabled"}>${esc(d.label)}${d.available ? "" : " — Pi only, unavailable here"}</option>`).join("");
  openModal(`<h3>${id ? "Edit" : "Add"} sensor</h3>
    <div class="field"><label>Name</label><input id="s-name" value="${esc(s.name)}" placeholder="Greenhouse climate"></div>
    <div class="row2">
      <div class="field"><label>Type</label><select id="s-driver" onchange="onDriverChange()">${opts}</select></div>
      <div class="field"><label>Poll interval (seconds)</label><input id="s-interval" type="number" min="0.5" step="0.5" value="${s.interval_sec}"></div>
    </div>
    <div id="s-fields">${driverFieldsHTML(s.driver, s.config)}</div>
    <div id="test-out" class="muted" style="font-size:12px;min-height:16px"></div>
    <div class="modal-actions">
      <button class="btn" onclick="testSensor()">Test read</button>
      <button class="btn" onclick="closeModal()">Cancel</button>
      <button class="btn primary" onclick="saveSensor(${id})">Save</button></div>`);
}
function onDriverChange() { $("#s-fields").innerHTML = driverFieldsHTML($("#s-driver").value, {}); }
async function testSensor() {
  const out = $("#test-out"); out.textContent = "testing…";
  try {
    const r = await API.post("/api/sensors/test", { driver: $("#s-driver").value, config: collectConfig() });
    out.innerHTML = r.ok ? `<span style="color:var(--accent)">✓ ${esc(JSON.stringify(r.metrics))}</span>`
                         : `<span style="color:var(--danger)">✕ ${esc(r.error)}</span>`;
  } catch (e) { out.innerHTML = `<span style="color:var(--danger)">✕ ${esc(e.message)}</span>`; }
}
async function saveSensor(id) {
  const body = { name: $("#s-name").value.trim(), driver: $("#s-driver").value,
    interval_sec: Number($("#s-interval").value), config: collectConfig() };
  if (!body.name) return toast("Name is required");
  try { if (id) await API.patch(`/api/sensors/${id}`, body); else await API.post("/api/sensors", body);
    closeModal(); toast("Sensor saved"); loadSensors(); }
  catch (e) { toast("Error: " + e.message); }
}

// ── DATA tab (realtime) ─────────────────────────────────────────────────────
async function loadDataTab() {
  SENSORS = await API.get("/api/sensors");
  const sel = $("#data-sensor");
  const prev = sel.value;
  sel.innerHTML = SENSORS.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("")
    || `<option value="">no sensors</option>`;
  if (prev) sel.value = prev;
  await loadData();
}
async function loadData() {
  const sid = $("#data-sensor").value;
  if (!sid) { $("#data-body").innerHTML = ""; dataState.sid = null; return; }
  const full = await API.get(`/api/sensors/${sid}`);
  const msel = $("#data-metric");
  const metrics = full.metrics || [];
  if (msel.dataset.for !== sid) {
    msel.innerHTML = metrics.map((m) => `<option>${esc(m)}</option>`).join("") || `<option value="">none</option>`;
    msel.dataset.for = sid;
  }
  const metric = msel.value || metrics[0] || "";
  const range = Number($("#data-range").value);
  const since = range ? Date.now() / 1000 - range : 0;
  const rows = await API.get(`/api/history?sensor_id=${sid}&metric=${encodeURIComponent(metric)}&since=${since || ""}&limit=5000`);
  Object.assign(dataState, { sid: Number(sid), metric, since, points: rows.slice().reverse().map((r) => ({ t: r.ts, v: r.value })) });
  $("#data-export").href = `/api/history/export.csv?sensor_id=${sid}`;
  $("#data-live").classList.add("on");
  drawChart($("#data-chart"), dataState.points);
  renderDataTable(rows.slice(0, 150));
  const st = await API.get("/api/history/stats");
  $("#data-stats").innerHTML = `<div class="kv"><span class="k">Total stored readings</span><span>${st.total.toLocaleString()}</span>
    <span class="k">Oldest</span><span>${st.first ? st.first.replace("T"," ").slice(0,19) : "—"}</span>
    <span class="k">Newest</span><span>${st.last ? st.last.replace("T"," ").slice(0,19) : "—"}</span></div>`;
}
function renderDataTable(rows) {
  $("#data-body").innerHTML = rows.map((r) =>
    `<tr><td>${esc((r.timestamp||"").replace("T"," ").slice(0,19))}</td><td>${esc(r.metric)}</td><td>${fmtNum(r.value)}</td></tr>`).join("")
    || `<tr><td colspan="3" class="empty">No data in range.</td></tr>`;
}
function appendLiveData(msg) {
  if (msg.sensor_id !== dataState.sid || dataState.metric == null) return;
  if (!(dataState.metric in msg.metrics)) return;
  dataState.points.push({ t: msg.ts, v: msg.metrics[dataState.metric] });
  if (dataState.since) dataState.points = dataState.points.filter((p) => p.t >= Date.now() / 1000 - (Date.now()/1000 - dataState.since));
  if (dataState.points.length > 6000) dataState.points.shift();
  drawChart($("#data-chart"), dataState.points);
  const body = $("#data-body");
  const t = new Date(msg.ts * 1000).toISOString().replace("T", " ").slice(0, 19);
  body.insertAdjacentHTML("afterbegin", `<tr><td>${esc(t)}</td><td>${esc(dataState.metric)}</td><td>${fmtNum(msg.metrics[dataState.metric])}</td></tr>`);
  if (body.children.length > 150) body.lastElementChild.remove();
}
async function deleteData() {
  const sid = $("#data-sensor").value; if (!sid) return;
  if (!confirm("Delete ALL stored readings for this sensor?")) return;
  const r = await API.del(`/api/history?sensor_id=${sid}`); toast(`Deleted ${r.deleted} rows`); loadData();
}

// ── CONTROL tab ─────────────────────────────────────────────────────────────
async function loadControl() {
  const [acts, status] = await Promise.all([API.get("/api/actuators"), API.get("/api/status")]);
  const onPi = status.is_raspberry_pi;
  $("#control-grid").innerHTML = acts.map((a) => {
    const on = a.state?.value == 1;
    const note = a.driver === "gpio_out" && !onPi ? `<div class="muted" style="font-size:11px;color:var(--warn);margin-top:4px">Pi-only — no effect on this machine</div>` : "";
    return `<div class="card">
      <div class="card-head"><h3>${esc(a.name)}</h3>
        <label class="switch"><input type="checkbox" ${on ? "checked" : ""} onchange="cmdActuator(${a.id}, this.checked ? 'on':'off')"><span class="slider"></span></label></div>
      <div class="sub">${esc(a.driver)}${a.driver === "gpio_out" ? " · pin " + (a.config?.pin ?? "?") : ""}</div>${note}
      <div class="actions" style="margin-top:10px">
        <button class="btn small" onclick="cmdActuator(${a.id},'toggle')">Toggle</button>
        <button class="btn icon small" title="Edit" onclick="openActuatorModal(${a.id})">${ic("edit")}</button>
        <button class="btn icon small danger" title="Delete" onclick="delActuator(${a.id})">${ic("trash")}</button>
      </div></div>`;
  }).join("") || emptyState("No actuators yet", "Add one to control a device (relay, LED, fan…).");
}
async function cmdActuator(id, action) {
  try { await API.post(`/api/actuators/${id}/command`, { action }); toast("Command sent"); loadControl(); }
  catch (e) { toast("Error: " + e.message); loadControl(); }
}
async function delActuator(id) { if (!confirm("Delete this actuator?")) return; await API.del(`/api/actuators/${id}`); loadControl(); }
async function openActuatorModal(id = null) {
  const a = id ? (await API.get("/api/actuators")).find((x) => x.id === id) : { name: "", driver: "http", config: {} };
  openModal(`<h3>${id ? "Edit" : "Add"} actuator</h3>
    <div class="field"><label>Name</label><input id="a-name" value="${esc(a.name)}" placeholder="Exhaust fan"></div>
    <div class="field"><label>Type</label><select id="a-driver" onchange="actuatorFields(this.value)">
      <option value="http"${a.driver==="http"?" selected":""}>HTTP node (POST command)</option>
      <option value="gpio_out"${a.driver==="gpio_out"?" selected":""}>Raspberry Pi GPIO output</option></select></div>
    <div id="a-fields"></div>
    <div class="modal-actions"><button class="btn" onclick="closeModal()">Cancel</button>
      <button class="btn primary" onclick="saveActuator(${id})">Save</button></div>`);
  actuatorFields(a.driver, a.config);
}
function actuatorFields(driver, cfg = {}) {
  $("#a-fields").innerHTML = driver === "gpio_out"
    ? `<div class="row2"><div class="field"><label>BCM pin</label><input id="a-pin" type="number" value="${esc(cfg.pin ?? "")}" placeholder="17"></div>
       <div class="field"><label>Active high</label><select id="a-activehigh"><option value="true"${cfg.active_high!==false?" selected":""}>Yes</option><option value="false"${cfg.active_high===false?" selected":""}>No</option></select></div></div>`
    : `<div class="field"><label>Command URL</label><input id="a-url" value="${esc(cfg.url ?? "")}" placeholder="http://192.168.0.100:5000/api/led"></div>`;
}
async function saveActuator(id) {
  const driver = $("#a-driver").value;
  const config = driver === "gpio_out"
    ? { pin: Number($("#a-pin").value), active_high: $("#a-activehigh").value === "true" }
    : { url: $("#a-url").value.trim() };
  const body = { name: $("#a-name").value.trim(), driver, config };
  if (!body.name) return toast("Name is required");
  try { if (id) await API.patch(`/api/actuators/${id}`, body); else await API.post("/api/actuators", body);
    closeModal(); toast("Actuator saved"); loadControl(); }
  catch (e) { toast("Error: " + e.message); }
}

// ── FORWARDING tab ──────────────────────────────────────────────────────────
async function loadForwarding() {
  const [targets, sensors] = await Promise.all([API.get("/api/forwards"), API.get("/api/sensors")]);
  const base = location.origin;
  $("#reexpose-info").innerHTML = `<div class="card-head"><h3>Pull API — always on, CORS-enabled</h3></div>
    <p class="muted" style="font-size:12.5px;margin:6px 0 10px">Other apps (e.g. PsychroMol's Sensor tab) read data straight from these URLs:</p>
    ${sensors.map((s) => `<div style="margin:3px 0">${esc(s.name)}: <code>${esc(base)}/api/sensors/${s.id}/latest</code></div>`).join("") || `<div class="muted">Add a sensor first.</div>`}`;
  $("#forward-body").innerHTML = targets.map((t) => {
    const dest = t.type === "webhook" ? esc(t.config?.url || "")
      : t.type === "mqtt" ? esc(`${t.config?.broker}:${t.config?.port||1883} → ${t.config?.topic||"(auto)"}`) : "";
    const names = t.sensor_filter == null ? "all"
      : t.sensor_filter.map((id) => esc((sensors.find((s) => s.id === id) || {}).name || id)).join(", ");
    const stErr = /error|can't|failed|unknown|timeout/i.test(t.last_status || "");
    return `<tr><td><b>${esc(t.name)}</b></td><td>${esc(t.type)}</td><td class="muted wrap" style="max-width:240px">${dest}</td>
      <td>${names}</td>
      <td><label class="switch"><input type="checkbox" ${t.enabled?"checked":""} onchange="toggleForward(${t.id},this.checked)"><span class="slider"></span></label></td>
      <td class="wrap" style="max-width:240px;${stErr?'color:var(--danger)':''}">${esc(t.last_status || "—")}</td>
      <td><button class="btn icon small danger" title="Delete" onclick="delForward(${t.id})">${ic("trash")}</button></td></tr>`;
  }).join("") || `<tr><td colspan="7" class="empty">No forward targets. Data is still available via the pull API above.</td></tr>`;
}
async function toggleForward(id, en) { await API.patch(`/api/forwards/${id}`, { enabled: en }); }
async function delForward(id) { if (!confirm("Delete this forward target?")) return; await API.del(`/api/forwards/${id}`); loadForwarding(); }
async function openForwardModal() {
  const sensors = await API.get("/api/sensors");
  openModal(`<h3>Add forward target</h3>
    <div class="field"><label>Name</label><input id="f-name" placeholder="Node-RED webhook"></div>
    <div class="field"><label>Type</label><select id="f-type" onchange="forwardFields(this.value)">
      <option value="webhook">Webhook — HTTP POST to a URL:port</option>
      <option value="mqtt">MQTT publish</option></select></div>
    <div id="f-fields"></div>
    <div class="field"><label>Which sensors? (none selected = all)</label>
      <select id="f-sensors" multiple size="${Math.min(4, Math.max(2, sensors.length || 2))}">
      ${sensors.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join("")}</select></div>
    <div class="modal-actions"><button class="btn" onclick="closeModal()">Cancel</button>
      <button class="btn primary" onclick="saveForward()">Save</button></div>`);
  forwardFields("webhook");
}
function forwardFields(type) {
  $("#f-fields").innerHTML = type === "webhook"
    ? `<div class="field"><label>Destination URL</label><input id="f-url" placeholder="http://192.168.0.50:1880/sensor"></div>`
    : `<div class="row2"><div class="field"><label>Broker host</label><input id="f-broker" placeholder="test.mosquitto.org"></div>
       <div class="field"><label>Port</label><input id="f-port" type="number" value="1883"></div></div>
       <div class="field"><label>Topic</label><input id="f-topic" placeholder="greenhouse/climate"></div>`;
}
async function saveForward() {
  const type = $("#f-type").value;
  const config = type === "webhook" ? { url: $("#f-url").value.trim() }
    : { broker: $("#f-broker").value.trim(), port: Number($("#f-port").value) || 1883, topic: $("#f-topic").value.trim() };
  const sel = [...$("#f-sensors").selectedOptions].map((o) => Number(o.value));
  const body = { name: $("#f-name").value.trim(), type, config, sensor_filter: sel.length ? sel : null };
  if (!body.name) return toast("Name is required");
  try { await API.post("/api/forwards", body); closeModal(); toast("Forward target added"); loadForwarding(); }
  catch (e) { toast("Error: " + e.message); }
}

// ── STATUS tab ──────────────────────────────────────────────────────────────
async function loadStatus() {
  const [s, events] = await Promise.all([API.get("/api/status"), API.get("/api/events?limit=80")]);
  const rows = [
    ["Application", `${s.app} v${s.version}`],
    ["Running on", s.is_raspberry_pi ? `Raspberry Pi (${esc(s.pi_model || "")})` : "Not a Pi"],
    ["Platform", s.platform], ["Python", s.python],
    ["Uptime", `${Math.floor(s.uptime_sec/3600)}h ${Math.floor(s.uptime_sec%3600/60)}m`],
    ["CPU", s.cpu_percent != null ? s.cpu_percent + "%" : "—"],
    ["Memory", s.mem_percent != null ? `${s.mem_percent}% (${s.mem_used_mb}/${s.mem_total_mb} MB)` : "—"],
    ["CPU temp", s.cpu_temp_c != null ? s.cpu_temp_c + " °C" : "—"],
    ["Stored readings", (s.readings?.total ?? 0).toLocaleString()],
    ["Database size", `${(s.db_size_bytes/1024).toFixed(0)} KB`],
  ];
  $("#status-kv").innerHTML = rows.map(([k, v]) => `<span class="k">${esc(k)}</span><span>${esc(v)}</span>`).join("");
  $("#event-log").innerHTML = events.map((e) =>
    `<div class="${esc(e.level)}"><span class="t">${esc(new Date(e.ts*1000).toLocaleTimeString())}</span> [${esc(e.source||"")}] ${esc(e.message)}</div>`).join("")
    || `<div class="muted">No events.</div>`;
}

// ── SETTINGS tab ────────────────────────────────────────────────────────────
async function loadSettings() {
  const s = await API.get("/api/settings");
  $("#set-cors").value = s.cors_origins ?? "*";
  $("#set-retention").value = s.retention_days ?? 30;
}
async function saveSettings() {
  await API.patch("/api/settings", { cors_origins: $("#set-cors").value.trim() || "*",
    retention_days: Number($("#set-retention").value) });
  toast("Settings saved");
}

// ── Charts (dependency-free, responsive) ────────────────────────────────────
function emptyState(title, sub) { return `<div class="empty" style="grid-column:1/-1"><b>${esc(title)}</b><br><span class="muted">${esc(sub)}</span></div>`; }
function drawSpark(id) {
  const cv = document.getElementById(`spark-${id}`); if (!cv) return;
  const buf = liveBuffers[id] || {}; const key = Object.keys(buf)[0]; if (!key) return;
  drawChart(cv, buf[key].map((v, i) => ({ t: i, v })), { spark: true });
}
function drawChart(canvas, data, opts = {}) {
  if (!canvas) return;
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth || 300, h = canvas.clientHeight || (opts.spark ? 40 : 260);
  canvas.width = w * dpr; canvas.height = h * dpr;
  const ctx = canvas.getContext("2d"); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
  if (!data.length) {
    if (!opts.spark) { ctx.fillStyle = "#9ca3af"; ctx.font = "13px system-ui"; ctx.fillText("No data yet", 12, h/2); }
    return;
  }
  const pad = opts.spark ? { l: 1, r: 1, t: 4, b: 4 } : { l: 48, r: 14, t: 12, b: 24 };
  const xs = data.map((d) => d.t), ys = data.map((d) => d.v);
  let minY = Math.min(...ys), maxY = Math.max(...ys); if (minY === maxY) { minY -= 1; maxY += 1; }
  const minX = Math.min(...xs), maxX = Math.max(...xs);
  const px = (t) => pad.l + (t - minX) / (maxX - minX || 1) * (w - pad.l - pad.r);
  const py = (v) => pad.t + (1 - (v - minY) / (maxY - minY)) * (h - pad.t - pad.b);
  const accent = "#16a34a";
  if (!opts.spark) {
    ctx.strokeStyle = "#eef0f2"; ctx.fillStyle = "#9ca3af"; ctx.font = "10px system-ui"; ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const v = minY + (maxY - minY) * i / 4, y = py(v);
      ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(w - pad.r, y); ctx.stroke();
      ctx.fillText(fmtNum(v), 6, y + 3);
    }
    ctx.fillText(new Date(xs[0]*1000).toLocaleTimeString(), pad.l, h - 7);
    const lbl = new Date(xs[xs.length-1]*1000).toLocaleTimeString();
    ctx.fillText(lbl, w - pad.r - ctx.measureText(lbl).width, h - 7);
  }
  ctx.beginPath(); ctx.moveTo(px(xs[0]), py(ys[0]));
  data.forEach((d) => ctx.lineTo(px(d.t), py(d.v)));
  ctx.lineTo(px(xs[xs.length-1]), h - pad.b); ctx.lineTo(px(xs[0]), h - pad.b); ctx.closePath();
  ctx.fillStyle = "rgba(22,163,74,.10)"; ctx.fill();
  ctx.beginPath(); ctx.moveTo(px(xs[0]), py(ys[0]));
  data.forEach((d) => ctx.lineTo(px(d.t), py(d.v)));
  ctx.strokeStyle = accent; ctx.lineWidth = opts.spark ? 1.5 : 2; ctx.lineJoin = "round"; ctx.stroke();
  if (!opts.spark) {
    const lx = px(xs[xs.length-1]), ly = py(ys[ys.length-1]);
    ctx.beginPath(); ctx.arc(lx, ly, 3, 0, 2*Math.PI); ctx.fillStyle = accent; ctx.fill();
  }
}
let _rz;
window.addEventListener("resize", () => {
  clearTimeout(_rz);
  _rz = setTimeout(() => {
    if (activeTab() === "live") SENSORS.forEach((s) => drawSpark(s.id));
    else if (activeTab() === "data") drawChart($("#data-chart"), dataState.points);
  }, 120);
});

// ── Wire static buttons + init ──────────────────────────────────────────────
$("#add-sensor").onclick = () => openSensorModal();
$("#add-actuator").onclick = () => openActuatorModal();
$("#add-forward").onclick = () => openForwardModal();
$("#data-sensor").onchange = () => { $("#data-metric").dataset.for = ""; loadData(); };
$("#data-metric").onchange = loadData;
$("#data-range").onchange = loadData;
$("#data-delete").onclick = deleteData;
$("#save-settings").onclick = saveSettings;

(async function init() {
  DRIVERS = await API.get("/api/drivers");
  connectWS();
  loadLive();
  setInterval(() => { if (activeTab() === "status") loadStatus(); }, 5000);
})();
