"""SensorHub FastAPI application — REST API + WebSocket + static dashboard.

Run:  uvicorn backend.main:app --host 0.0.0.0 --port 8000
  or:  python -m backend  (see backend/__main__.py)
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import (actuators, bus, config, db, drivers, forwarding, history,
               scheduler, sensors, status)


# ── Lifecycle ────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(_app: FastAPI):
    db.init_db()
    bus.set_loop(asyncio.get_running_loop())
    scheduler.start()
    db.log_event("info", f"{config.APP_NAME} {config.APP_VERSION} started", "system")
    yield
    scheduler.shutdown()


app = FastAPI(title=config.APP_NAME, version=config.APP_VERSION, lifespan=lifespan)

# CORS so external pages (e.g. PsychroMol) can fetch the re-exposed API.
_origins = db.get_setting("cors_origins", "*") if config.DB_PATH.exists() else "*"
_allow = ["*"] if _origins in ("*", "", None) else [o.strip() for o in str(_origins).split(",")]
app.add_middleware(
    CORSMiddleware, allow_origins=_allow, allow_methods=["*"], allow_headers=["*"],
)


# ── Request models ───────────────────────────────────────────────────────

class SensorIn(BaseModel):
    name: str
    driver: str
    config: dict = {}
    interval_sec: float = 5
    enabled: bool = True


class SensorPatch(BaseModel):
    name: Optional[str] = None
    driver: Optional[str] = None
    config: Optional[dict] = None
    interval_sec: Optional[float] = None
    enabled: Optional[bool] = None


class TestIn(BaseModel):
    driver: str
    config: dict = {}


class ActuatorIn(BaseModel):
    name: str
    driver: str
    config: dict = {}
    enabled: bool = True


class ActuatorPatch(BaseModel):
    name: Optional[str] = None
    driver: Optional[str] = None
    config: Optional[dict] = None
    enabled: Optional[bool] = None


class ForwardIn(BaseModel):
    name: str
    type: str
    config: dict = {}
    sensor_filter: Optional[list[int]] = None
    enabled: bool = True


class ForwardPatch(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    config: Optional[dict] = None
    sensor_filter: Optional[list[int]] = None
    enabled: Optional[bool] = None


# ── System / meta ────────────────────────────────────────────────────────

@app.get("/api/status")
def api_status():
    return status.system_status()


@app.get("/api/drivers")
def api_drivers():
    return drivers.list_drivers()


@app.get("/api/events")
def api_events(limit: int = 100):
    return db.recent_events(limit)


@app.get("/api/settings")
def api_get_settings():
    return db.all_settings()


@app.patch("/api/settings")
def api_patch_settings(values: dict[str, Any]):
    for k, v in values.items():
        db.set_setting(k, v)
    return db.all_settings()


# ── Sensors ──────────────────────────────────────────────────────────────

@app.get("/api/sensors")
def api_sensors():
    out = sensors.list_sensors()
    for s in out:
        s["latest"] = sensors.latest(s["id"])
    return out


@app.post("/api/sensors")
def api_create_sensor(body: SensorIn):
    try:
        sid = sensors.create_sensor(body.name, body.driver, body.config,
                                    body.interval_sec, body.enabled)
    except ValueError as e:
        raise HTTPException(400, str(e))
    scheduler.reload_jobs()
    return sensors.get_sensor(sid)


@app.get("/api/sensors/{sensor_id}")
def api_get_sensor(sensor_id: int):
    s = sensors.get_sensor(sensor_id)
    if not s:
        raise HTTPException(404, "sensor not found")
    s["latest"] = sensors.latest(sensor_id)
    s["metrics"] = history.metrics_for(sensor_id)
    return s


@app.patch("/api/sensors/{sensor_id}")
def api_update_sensor(sensor_id: int, body: SensorPatch):
    if not sensors.get_sensor(sensor_id):
        raise HTTPException(404, "sensor not found")
    sensors.update_sensor(sensor_id, **body.model_dump(exclude_none=True))
    scheduler.reload_jobs()
    return sensors.get_sensor(sensor_id)


@app.delete("/api/sensors/{sensor_id}")
def api_delete_sensor(sensor_id: int):
    sensors.delete_sensor(sensor_id)
    scheduler.reload_jobs()
    return {"ok": True}


@app.post("/api/sensors/test")
def api_test_sensor(body: TestIn):
    return sensors.test_read(body.driver, body.config)


# Re-exposed clean pull API (CORS-enabled) — PsychroMol & others read these.
@app.get("/api/sensors/{sensor_id}/latest")
def api_sensor_latest(sensor_id: int):
    if not sensors.get_sensor(sensor_id):
        raise HTTPException(404, "sensor not found")
    result = sensors.latest(sensor_id)
    # Flatten metrics to top level too, so e.g. {"tdb":..,"w":..} is directly usable.
    flat = dict(result["metrics"])
    flat["timestamp"] = result["timestamp"]
    return flat


@app.get("/api/sensors/{sensor_id}/history")
def api_sensor_history(sensor_id: int, metric: Optional[str] = None,
                       since: Optional[float] = None, limit: int = 2000):
    return history.query(sensor_id=sensor_id, metric=metric, since=since, limit=limit)


# ── History / data ───────────────────────────────────────────────────────

@app.get("/api/history")
def api_history(sensor_id: Optional[int] = None, metric: Optional[str] = None,
                since: Optional[float] = None, until: Optional[float] = None,
                limit: int = 5000):
    return history.query(sensor_id, metric, since, until, limit)


@app.get("/api/history/stats")
def api_history_stats():
    return history.stats()


@app.get("/api/history/export.csv")
def api_history_csv(sensor_id: Optional[int] = None, metric: Optional[str] = None,
                    since: Optional[float] = None, until: Optional[float] = None):
    rows = history.query(sensor_id, metric, since, until, limit=1_000_000)
    return PlainTextResponse(history.to_csv(rows), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=sensorhub.csv"})


@app.delete("/api/history")
def api_history_delete(sensor_id: Optional[int] = None, before: Optional[float] = None):
    return {"deleted": history.delete(sensor_id=sensor_id, before=before)}


# ── Actuators / control ──────────────────────────────────────────────────

@app.get("/api/actuators")
def api_actuators():
    return actuators.list_actuators()


@app.post("/api/actuators")
def api_create_actuator(body: ActuatorIn):
    try:
        aid = actuators.create_actuator(body.name, body.driver, body.config, body.enabled)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return actuators.get_actuator(aid)


@app.patch("/api/actuators/{aid}")
def api_update_actuator(aid: int, body: ActuatorPatch):
    if not actuators.get_actuator(aid):
        raise HTTPException(404, "actuator not found")
    actuators.update_actuator(aid, **body.model_dump(exclude_none=True))
    return actuators.get_actuator(aid)


@app.delete("/api/actuators/{aid}")
def api_delete_actuator(aid: int):
    actuators.delete_actuator(aid)
    return {"ok": True}


@app.post("/api/actuators/{aid}/command")
def api_actuator_command(aid: int, payload: dict[str, Any]):
    try:
        return {"ok": True, "state": actuators.command(aid, payload)}
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, str(e))


# ── Forwarding ───────────────────────────────────────────────────────────

@app.get("/api/forwards")
def api_forwards():
    return forwarding.list_targets()


@app.post("/api/forwards")
def api_create_forward(body: ForwardIn):
    fid = forwarding.create_target(body.name, body.type, body.config,
                                   body.sensor_filter, body.enabled)
    return forwarding.get_target(fid)


@app.patch("/api/forwards/{fid}")
def api_update_forward(fid: int, body: ForwardPatch):
    if not forwarding.get_target(fid):
        raise HTTPException(404, "target not found")
    forwarding.update_target(fid, **body.model_dump(exclude_none=True))
    return forwarding.get_target(fid)


@app.delete("/api/forwards/{fid}")
def api_delete_forward(fid: int):
    forwarding.delete_target(fid)
    return {"ok": True}


# ── WebSocket (live updates) ─────────────────────────────────────────────

@app.websocket("/ws")
async def ws_endpoint(websocket: WebSocket):
    await bus.register(websocket)
    try:
        while True:
            await websocket.receive_text()  # inbound ignored; keeps the socket open
    except WebSocketDisconnect:
        bus.unregister(websocket)


# ── Static dashboard (mounted last so /api/* wins) ───────────────────────

@app.get("/")
def index():
    return FileResponse(config.WEB_DIR / "index.html")


app.mount("/", StaticFiles(directory=config.WEB_DIR, html=True), name="web")
