"""Static configuration & paths for SensorHub.

User-adjustable settings (CORS origins, retention days, …) live in the SQLite
`settings` table and are read via db.get_setting(); this module only holds the
things needed before the database exists (paths, default port).
"""
from __future__ import annotations

import os
from pathlib import Path

# ── Paths ────────────────────────────────────────────────────────────────
# Project root = the sensor-hub/ folder (parent of backend/).
BASE_DIR = Path(__file__).resolve().parent.parent
WEB_DIR = BASE_DIR / "web"
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = Path(os.environ.get("SENSORHUB_DB", DATA_DIR / "sensorhub.db"))

# ── Network ──────────────────────────────────────────────────────────────
HOST = os.environ.get("SENSORHUB_HOST", "0.0.0.0")  # all interfaces → reachable on the LAN
PORT = int(os.environ.get("SENSORHUB_PORT", "8000"))

# ── Defaults for settings stored in the DB on first run ──────────────────
DEFAULT_SETTINGS = {
    # Which browser origins may fetch the hub API (PsychroMol etc.). "*" = any.
    "cors_origins": "*",
    # Auto-delete stored readings older than this many days (0 = keep forever).
    "retention_days": 30,
    # How often the retention/cleanup job runs, in minutes.
    "cleanup_interval_min": 60,
}

APP_NAME = "SensorHub"
APP_VERSION = "0.1.0"
