"""Tiny publish/subscribe bus for pushing live updates to dashboard browsers
over WebSocket.

The background poller runs in a worker thread, so it can't `await` directly;
`publish_threadsafe` hands the message to the main asyncio loop safely.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

from fastapi import WebSocket

_clients: set[WebSocket] = set()
_loop: asyncio.AbstractEventLoop | None = None


def set_loop(loop: asyncio.AbstractEventLoop) -> None:
    global _loop
    _loop = loop


async def register(ws: WebSocket) -> None:
    await ws.accept()
    _clients.add(ws)


def unregister(ws: WebSocket) -> None:
    _clients.discard(ws)


async def _send_all(message: dict) -> None:
    if not _clients:
        return
    data = json.dumps(message, default=str)
    dead = []
    for ws in list(_clients):
        try:
            await ws.send_text(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        _clients.discard(ws)


async def publish(message: dict) -> None:
    await _send_all(message)


def publish_threadsafe(message: dict[str, Any]) -> None:
    """Broadcast from any thread (e.g. the poller)."""
    if _loop is None:
        return
    try:
        asyncio.run_coroutine_threadsafe(_send_all(message), _loop)
    except RuntimeError:
        pass
