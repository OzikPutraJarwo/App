"""Sensor configs, one-off test reads, and the poll routine.

poll_sensor() is what the scheduler calls on each interval: read the driver,
store every metric, update the sensor's health, push a live update to browsers,
and hand the reading to the forwarding subsystem.
"""
from __future__ import annotations

import json
import time

from . import bus, db, drivers, forwarding


# ── CRUD ─────────────────────────────────────────────────────────────────

def list_sensors() -> list[dict]:
    return db.fetch_all("SELECT * FROM sensors ORDER BY id")


def get_sensor(sensor_id: int) -> dict | None:
    return db.fetch_one("SELECT * FROM sensors WHERE id=?", (sensor_id,))


def create_sensor(name: str, driver: str, config: dict, interval_sec: float = 5,
                  enabled: bool = True) -> int:
    if driver not in drivers.REGISTRY:
        raise ValueError(f"unknown driver '{driver}'")
    return db.execute(
        "INSERT INTO sensors(name, driver, config, interval_sec, enabled, status, created_at) "
        "VALUES (?,?,?,?,?,?,?)",
        (name, driver, json.dumps(config or {}), float(interval_sec),
         1 if enabled else 0, "idle", time.time()),
    )


def update_sensor(sensor_id: int, **fields) -> None:
    allowed = {"name", "driver", "config", "interval_sec", "enabled"}
    sets, params = [], []
    for k, v in fields.items():
        if k not in allowed:
            continue
        if k == "config":
            v = json.dumps(v)
        if k == "enabled":
            v = 1 if v else 0
        sets.append(f"{k}=?")
        params.append(v)
    if not sets:
        return
    params.append(sensor_id)
    db.execute(f"UPDATE sensors SET {', '.join(sets)} WHERE id=?", params)


def delete_sensor(sensor_id: int) -> None:
    db.execute("DELETE FROM sensors WHERE id=?", (sensor_id,))


def latest(sensor_id: int) -> dict:
    """Most recent value of every metric for one sensor (for the pull API)."""
    rows = db.fetch_all(
        "SELECT r.metric, r.value, r.ts FROM readings r "
        "JOIN (SELECT metric, MAX(ts) AS mts FROM readings WHERE sensor_id=? GROUP BY metric) m "
        "  ON r.metric=m.metric AND r.ts=m.mts "
        "WHERE r.sensor_id=?",
        (sensor_id, sensor_id),
    )
    metrics = {r["metric"]: r["value"] for r in rows}
    ts = max((r["ts"] for r in rows), default=None)
    return {"metrics": metrics, "ts": ts, "timestamp": _iso(ts) if ts else None}


# ── Test read (for the "Test" button; does not store) ────────────────────

def test_read(driver: str, config: dict) -> dict:
    try:
        return {"ok": True, "metrics": drivers.read(driver, config)}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": str(exc)}


# ── Poll (scheduled) ─────────────────────────────────────────────────────

def poll_sensor(sensor_id: int) -> None:
    sensor = get_sensor(sensor_id)
    if not sensor or not sensor.get("enabled"):
        return
    ts = time.time()
    try:
        metrics = drivers.read(sensor["driver"], sensor.get("config") or {})
    except Exception as exc:  # noqa: BLE001
        db.execute("UPDATE sensors SET status='error', last_error=? WHERE id=?",
                   (str(exc), sensor_id))
        db.log_event("error", f"sensor '{sensor['name']}' read failed: {exc}", "sensors")
        bus.publish_threadsafe({"type": "sensor_status",
                                "sensor_id": sensor_id, "status": "error", "error": str(exc)})
        return

    # Store one row per metric.
    conn = db.connect()
    try:
        conn.executemany(
            "INSERT INTO readings(sensor_id, ts, metric, value) VALUES (?,?,?,?)",
            [(sensor_id, ts, m, float(v)) for m, v in metrics.items()],
        )
        conn.execute("UPDATE sensors SET status='online', last_error=NULL, last_seen=? WHERE id=?",
                     (ts, sensor_id))
        conn.commit()
    finally:
        conn.close()

    bus.publish_threadsafe({
        "type": "reading", "sensor_id": sensor_id, "name": sensor["name"],
        "ts": ts, "metrics": metrics,
    })

    # Forward onward (webhook / mqtt). Never let a forwarding hiccup break polling.
    try:
        forwarding.dispatch(sensor, ts, metrics)
    except Exception as exc:  # noqa: BLE001
        db.log_event("warn", f"forwarding for '{sensor['name']}' errored: {exc}", "sensors")


def _iso(ts: float) -> str:
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
