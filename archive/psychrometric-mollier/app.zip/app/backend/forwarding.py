"""Forwarding — push each new reading onward to external targets.

Target types:
  webhook  -> HTTP POST {sensor, ts, metrics} to a URL:port
  mqtt     -> publish JSON to a broker/topic
The third option the user picked, "re-expose as clean API", needs no active
target: the pull endpoints /api/sensors/{id}/latest and /history are always on
(see main.py) and CORS-enabled so PsychroMol can read them.
"""
from __future__ import annotations

import json
import time

import httpx

from . import db

# Persistent MQTT clients, keyed by target id (connect once, reuse).
_mqtt_clients: dict[int, object] = {}


def list_targets() -> list[dict]:
    return db.fetch_all("SELECT * FROM forward_targets ORDER BY id")


def get_target(target_id: int) -> dict | None:
    return db.fetch_one("SELECT * FROM forward_targets WHERE id=?", (target_id,))


def create_target(name: str, ttype: str, config: dict, sensor_filter=None, enabled=True) -> int:
    return db.execute(
        "INSERT INTO forward_targets(name, type, config, sensor_filter, enabled, created_at) "
        "VALUES (?,?,?,?,?,?)",
        (name, ttype, json.dumps(config or {}), json.dumps(sensor_filter),
         1 if enabled else 0, time.time()),
    )


def update_target(target_id: int, **fields) -> None:
    allowed = {"name", "type", "config", "sensor_filter", "enabled"}
    sets, params = [], []
    for k, v in fields.items():
        if k not in allowed:
            continue
        if k in ("config", "sensor_filter"):
            v = json.dumps(v)
        if k == "enabled":
            v = 1 if v else 0
        sets.append(f"{k}=?")
        params.append(v)
    if not sets:
        return
    params.append(target_id)
    db.execute(f"UPDATE forward_targets SET {', '.join(sets)} WHERE id=?", params)
    if target_id in _mqtt_clients:  # config may have changed → drop cached client
        _drop_mqtt(target_id)


def delete_target(target_id: int) -> None:
    _drop_mqtt(target_id)
    db.execute("DELETE FROM forward_targets WHERE id=?", (target_id,))


def _matches(target: dict, sensor_id: int) -> bool:
    flt = target.get("sensor_filter")
    return flt is None or (isinstance(flt, list) and sensor_id in flt)


def _mark(target_id: int, status: str) -> None:
    db.execute(
        "UPDATE forward_targets SET last_status=?, last_sent_at=? WHERE id=?",
        (status, time.time(), target_id),
    )


# ── Dispatch (called by the poller for every stored reading) ─────────────

def dispatch(sensor: dict, ts: float, metrics: dict) -> None:
    payload = {
        "sensor_id": sensor["id"],
        "sensor": sensor["name"],
        "ts": ts,
        "timestamp": _iso(ts),
        "metrics": metrics,
    }
    for target in list_targets():
        if not target.get("enabled") or not _matches(target, sensor["id"]):
            continue
        try:
            if target["type"] == "webhook":
                _send_webhook(target, payload)
            elif target["type"] == "mqtt":
                _send_mqtt(target, payload)
            _mark(target["id"], "ok")
        except Exception as exc:  # noqa: BLE001 — record and keep going
            msg = _friendly_error(target, exc)
            _mark(target["id"], msg)
            db.log_event("warn", f"forward '{target['name']}': {msg}", "forwarding")


def _friendly_error(target: dict, exc: Exception) -> str:
    """Turn low-level network errors into a plain hint the user can act on."""
    cfg = target.get("config") or {}
    dest = cfg.get("url") or f"{cfg.get('broker')}:{cfg.get('port', 1883)}"
    text = str(exc)
    if "Connection refused" in text or "Errno 111" in text:
        return f"can't reach {dest} — is that destination running and the URL/port correct?"
    if "Name or service not known" in text or "getaddrinfo" in text:
        return f"unknown host in {dest} — check the address."
    if "timed out" in text.lower():
        return f"{dest} did not respond in time (timeout)."
    return f"failed sending to {dest}: {text}"


def _send_webhook(target: dict, payload: dict) -> None:
    cfg = target.get("config") or {}
    url = cfg.get("url")
    if not url:
        raise ValueError("webhook target has no url")
    timeout = float(cfg.get("timeout", 8))
    with httpx.Client(timeout=timeout) as client:
        client.post(url, json=payload).raise_for_status()


def _send_mqtt(target: dict, payload: dict) -> None:
    cfg = target.get("config") or {}
    topic = cfg.get("topic") or f"sensorhub/{payload['sensor_id']}"
    client = _mqtt_client(target["id"], cfg)
    info = client.publish(topic, json.dumps(payload, default=str), qos=int(cfg.get("qos", 0)))
    info.wait_for_publish(timeout=5)


def _mqtt_client(target_id: int, cfg: dict):
    import paho.mqtt.client as mqtt  # imported here so a broken MQTT install can't block the app

    client = _mqtt_clients.get(target_id)
    if client is not None and client.is_connected():
        return client
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    if cfg.get("username"):
        client.username_pw_set(cfg["username"], cfg.get("password", ""))
    client.connect(cfg.get("broker", "localhost"), int(cfg.get("port", 1883)), keepalive=30)
    client.loop_start()
    _mqtt_clients[target_id] = client
    return client


def _drop_mqtt(target_id: int) -> None:
    client = _mqtt_clients.pop(target_id, None)
    if client is not None:
        try:
            client.loop_stop()
            client.disconnect()
        except Exception:
            pass


def _iso(ts: float) -> str:
    from datetime import datetime, timezone
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
