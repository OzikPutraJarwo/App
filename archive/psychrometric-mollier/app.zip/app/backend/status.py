"""System & health status for the Status tab."""
from __future__ import annotations

import os
import platform
import time

from . import config, db, history
from .drivers.base import is_raspberry_pi

_START_TIME = time.time()


def _pi_model() -> str | None:
    try:
        with open("/proc/device-tree/model", "r", encoding="utf-8", errors="ignore") as f:
            return f.read().strip("\x00").strip()
    except OSError:
        return None


def _cpu_temp_c() -> float | None:
    # Raspberry Pi / Linux thermal zone.
    for path in ("/sys/class/thermal/thermal_zone0/temp",):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return round(int(f.read().strip()) / 1000.0, 1)
        except (OSError, ValueError):
            continue
    return None


def system_status() -> dict:
    info: dict = {
        "app": config.APP_NAME,
        "version": config.APP_VERSION,
        "is_raspberry_pi": is_raspberry_pi(),
        "pi_model": _pi_model(),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "uptime_sec": round(time.time() - _START_TIME),
        "cpu_temp_c": _cpu_temp_c(),
        "db_path": str(config.DB_PATH),
        "db_size_bytes": config.DB_PATH.stat().st_size if config.DB_PATH.exists() else 0,
        "readings": history.stats(),
    }
    try:
        import psutil
        info["cpu_percent"] = psutil.cpu_percent(interval=None)
        vm = psutil.virtual_memory()
        info["mem_percent"] = vm.percent
        info["mem_used_mb"] = round(vm.used / 1_048_576)
        info["mem_total_mb"] = round(vm.total / 1_048_576)
        info["load_avg"] = list(os.getloadavg()) if hasattr(os, "getloadavg") else None
    except Exception:
        pass
    return info
