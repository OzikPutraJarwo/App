"""SQLite data layer for SensorHub.

One SQLite file holds everything: sensor configs, time-series readings,
actuators, forward targets, an event log, and settings. WAL mode is enabled so
the background poller thread and the web requests can read/write concurrently.

A fresh connection is opened per call (cheap for SQLite) which keeps things
thread-safe without a shared connection or locks.
"""
from __future__ import annotations

import json
import sqlite3
import time
from typing import Any, Iterable, Optional

from . import config

# ── Connection ───────────────────────────────────────────────────────────

def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(config.DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def _row_to_dict(row: sqlite3.Row) -> dict:
    d = dict(row)
    # Decode any column named "config"/"state"/"sensor_filter" that holds JSON.
    for k in ("config", "state", "sensor_filter"):
        if k in d and isinstance(d[k], str) and d[k]:
            try:
                d[k] = json.loads(d[k])
            except (json.JSONDecodeError, TypeError):
                pass
    return d


# ── Schema ───────────────────────────────────────────────────────────────

SCHEMA = """
CREATE TABLE IF NOT EXISTS sensors (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL,
    driver       TEXT NOT NULL,               -- http | gpio_digital | dht22 | ds18b20
    config       TEXT NOT NULL DEFAULT '{}',  -- JSON: driver-specific params + field map
    interval_sec REAL NOT NULL DEFAULT 5,
    enabled      INTEGER NOT NULL DEFAULT 1,
    status       TEXT NOT NULL DEFAULT 'idle',-- idle | online | offline | error
    last_error   TEXT,
    last_seen    REAL,
    created_at   REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS readings (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    sensor_id INTEGER NOT NULL,
    ts        REAL NOT NULL,                  -- epoch seconds (UTC)
    metric    TEXT NOT NULL,                  -- e.g. tdb, w, rh
    value     REAL NOT NULL,
    FOREIGN KEY (sensor_id) REFERENCES sensors(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_readings_sensor_ts ON readings(sensor_id, ts);
CREATE INDEX IF NOT EXISTS idx_readings_lookup ON readings(sensor_id, metric, ts);

CREATE TABLE IF NOT EXISTS actuators (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    name     TEXT NOT NULL,
    driver   TEXT NOT NULL,                   -- gpio_out | http
    config   TEXT NOT NULL DEFAULT '{}',
    state    TEXT NOT NULL DEFAULT '{}',      -- last known state (JSON)
    enabled  INTEGER NOT NULL DEFAULT 1,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS forward_targets (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    type          TEXT NOT NULL,              -- webhook | mqtt | reexpose
    config        TEXT NOT NULL DEFAULT '{}',
    sensor_filter TEXT NOT NULL DEFAULT 'null', -- JSON: null=all, or [sensor_id,...]
    enabled       INTEGER NOT NULL DEFAULT 1,
    last_status   TEXT,
    last_sent_at  REAL,
    created_at    REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    ts      REAL NOT NULL,
    level   TEXT NOT NULL,                    -- info | warn | error
    source  TEXT,
    message TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


def init_db() -> None:
    conn = connect()
    try:
        conn.executescript(SCHEMA)
        # Seed default settings if missing.
        for key, val in config.DEFAULT_SETTINGS.items():
            conn.execute(
                "INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)",
                (key, json.dumps(val)),
            )
        conn.commit()
    finally:
        conn.close()


# ── Settings ─────────────────────────────────────────────────────────────

def get_setting(key: str, default: Any = None) -> Any:
    conn = connect()
    try:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if row is None:
            return default
        return json.loads(row["value"])
    finally:
        conn.close()


def set_setting(key: str, value: Any) -> None:
    conn = connect()
    try:
        conn.execute(
            "INSERT INTO settings(key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value)),
        )
        conn.commit()
    finally:
        conn.close()


def all_settings() -> dict:
    conn = connect()
    try:
        rows = conn.execute("SELECT key, value FROM settings").fetchall()
        return {r["key"]: json.loads(r["value"]) for r in rows}
    finally:
        conn.close()


# ── Events / log ─────────────────────────────────────────────────────────

def log_event(level: str, message: str, source: str = "") -> None:
    conn = connect()
    try:
        conn.execute(
            "INSERT INTO events(ts, level, source, message) VALUES (?, ?, ?, ?)",
            (time.time(), level, source, message),
        )
        conn.commit()
    finally:
        conn.close()


def recent_events(limit: int = 100) -> list[dict]:
    conn = connect()
    try:
        rows = conn.execute(
            "SELECT * FROM events ORDER BY ts DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Generic small helpers used by the resource modules ───────────────────

def fetch_all(sql: str, params: Iterable = ()) -> list[dict]:
    conn = connect()
    try:
        rows = conn.execute(sql, tuple(params)).fetchall()
        return [_row_to_dict(r) for r in rows]
    finally:
        conn.close()


def fetch_one(sql: str, params: Iterable = ()) -> Optional[dict]:
    conn = connect()
    try:
        row = conn.execute(sql, tuple(params)).fetchone()
        return _row_to_dict(row) if row else None
    finally:
        conn.close()


def execute(sql: str, params: Iterable = ()) -> int:
    """Run a write statement; return lastrowid (for INSERT) or rowcount."""
    conn = connect()
    try:
        cur = conn.execute(sql, tuple(params))
        conn.commit()
        return cur.lastrowid or cur.rowcount
    finally:
        conn.close()
