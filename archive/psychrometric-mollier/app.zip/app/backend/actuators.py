"""Actuators — send commands out to control devices.

Drivers:
  gpio_out -> set a Raspberry Pi output pin (relay, LED, pump). Pi-only.
  http     -> POST a command to a node's URL (e.g. a controllable app.py).

Command payload from the UI is a small dict, e.g. {"action": "on"} or
{"value": 1}. The last known state is stored so the dashboard can show toggles.
"""
from __future__ import annotations

import json
import time

import httpx

from . import bus, db

_gpio_devices: dict[int, object] = {}


# ── CRUD ─────────────────────────────────────────────────────────────────

def list_actuators() -> list[dict]:
    return db.fetch_all("SELECT * FROM actuators ORDER BY id")


def get_actuator(aid: int) -> dict | None:
    return db.fetch_one("SELECT * FROM actuators WHERE id=?", (aid,))


def create_actuator(name: str, driver: str, config: dict, enabled: bool = True) -> int:
    if driver not in ("gpio_out", "http"):
        raise ValueError(f"unknown actuator driver '{driver}'")
    return db.execute(
        "INSERT INTO actuators(name, driver, config, state, enabled, created_at) "
        "VALUES (?,?,?,?,?,?)",
        (name, driver, json.dumps(config or {}), json.dumps({}),
         1 if enabled else 0, time.time()),
    )


def update_actuator(aid: int, **fields) -> None:
    allowed = {"name", "driver", "config", "enabled"}
    sets, params = [], []
    for k, v in fields.items():
        if k not in allowed:
            continue
        if k == "config":
            v = json.dumps(v)
        if k == "enabled":
            v = 1 if v else 0
        sets.append(f"{k}=?")
        params.append(v)
    if not sets:
        return
    params.append(aid)
    db.execute(f"UPDATE actuators SET {', '.join(sets)} WHERE id=?", params)


def delete_actuator(aid: int) -> None:
    dev = _gpio_devices.pop(aid, None)
    if dev is not None:
        try:
            dev.close()
        except Exception:
            pass
    db.execute("DELETE FROM actuators WHERE id=?", (aid,))


# ── Command dispatch ─────────────────────────────────────────────────────

def command(aid: int, payload: dict) -> dict:
    act = get_actuator(aid)
    if not act:
        raise ValueError("actuator not found")
    if not act.get("enabled"):
        raise ValueError("actuator is disabled")

    if act["driver"] == "gpio_out":
        state = _gpio_command(aid, act.get("config") or {}, payload)
    elif act["driver"] == "http":
        state = _http_command(act.get("config") or {}, payload)
    else:
        raise ValueError(f"unknown driver '{act['driver']}'")

    db.execute("UPDATE actuators SET state=? WHERE id=?", (json.dumps(state), aid))
    db.log_event("info", f"actuator '{act['name']}' <- {payload}", "actuators")
    bus.publish_threadsafe({"type": "actuator_state", "actuator_id": aid, "state": state})
    return state


def _resolve_value(payload: dict, current: float) -> float:
    if "value" in payload:
        return 1.0 if payload["value"] else 0.0
    action = str(payload.get("action", "")).lower()
    if action == "on":
        return 1.0
    if action == "off":
        return 0.0
    if action == "toggle":
        return 0.0 if current else 1.0
    raise ValueError("command needs 'value' or 'action' (on/off/toggle)")


def _gpio_command(aid: int, cfg: dict, payload: dict) -> dict:
    from gpiozero import OutputDevice  # deferred: Pi-only

    pin = int(cfg["pin"])
    active_high = bool(cfg.get("active_high", True))
    dev = _gpio_devices.get(aid)
    if dev is None:
        dev = OutputDevice(pin, active_high=active_high, initial_value=False)
        _gpio_devices[aid] = dev
    value = _resolve_value(payload, float(dev.value))
    dev.value = bool(value)
    return {"value": int(value), "pin": pin}


def _http_command(cfg: dict, payload: dict) -> dict:
    url = cfg.get("url")
    if not url:
        raise ValueError("http actuator has no url")
    method = (cfg.get("method") or "POST").upper()
    timeout = float(cfg.get("timeout", 8))
    with httpx.Client(timeout=timeout) as client:
        resp = client.request(method, url, json=payload)
        resp.raise_for_status()
        body = None
        try:
            body = resp.json()
        except Exception:
            body = resp.text
    return {"sent": payload, "response": body}
