"""Background scheduler — one interval job per enabled sensor, plus a periodic
data-retention cleanup. Jobs run in a thread pool so blocking driver reads
(HTTP, GPIO) don't stall the web server.
"""
from __future__ import annotations

from apscheduler.schedulers.background import BackgroundScheduler

from . import db, history, sensors

_scheduler: BackgroundScheduler | None = None


def start() -> None:
    global _scheduler
    _scheduler = BackgroundScheduler(job_defaults={"coalesce": True, "max_instances": 1})
    _scheduler.start()
    reload_jobs()
    _schedule_cleanup()


def shutdown() -> None:
    if _scheduler:
        _scheduler.shutdown(wait=False)


def reload_jobs() -> None:
    """Re-sync sensor poll jobs to the current DB state (call after any CRUD)."""
    if not _scheduler:
        return
    wanted = {}
    for s in sensors.list_sensors():
        if s.get("enabled"):
            wanted[s["id"]] = float(s.get("interval_sec") or 5)

    existing = {j.id for j in _scheduler.get_jobs() if j.id.startswith("sensor:")}
    for job_id in existing:  # drop jobs for deleted/disabled sensors
        sid = int(job_id.split(":")[1])
        if sid not in wanted:
            _scheduler.remove_job(job_id)

    for sid, interval in wanted.items():
        # Repeating poll at the configured interval. (Do NOT pass next_run_time=None —
        # that would add the job in a paused state and it would never fire.)
        _scheduler.add_job(
            sensors.poll_sensor, "interval", seconds=max(0.5, interval),
            args=[sid], id=f"sensor:{sid}", replace_existing=True,
        )
        # Fire an immediate first read so the dashboard isn't empty on start.
        _scheduler.add_job(sensors.poll_sensor, "date", args=[sid],
                           id=f"sensor-now:{sid}", replace_existing=True)


def _schedule_cleanup() -> None:
    minutes = float(db.get_setting("cleanup_interval_min", 60))
    _scheduler.add_job(history.prune_old, "interval", minutes=max(1.0, minutes),
                       id="cleanup", replace_existing=True)
