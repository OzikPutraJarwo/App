"""HTTP source driver — poll a JSON endpoint and extract metrics.

Works with any node that returns JSON over HTTP, e.g. the Pi's app.py at
http://192.168.0.100:5000/api/led. You map each metric to a field path
(dotted paths like "data.temp" are supported).

config example:
{
  "url": "http://192.168.0.100:5000/api/led",
  "method": "GET",
  "timeout": 8,
  "fields": { "value": "value" }        # metric_name -> json field path
}
"""
from __future__ import annotations

import httpx

from .base import coerce_number, get_by_path

INFO = {
    "key": "http",
    "label": "HTTP / web endpoint",
    "pi_only": False,
    "description": "Poll any URL that returns JSON. Map metrics to JSON fields (dotted paths ok).",
    "fields": [
        {"name": "url", "label": "Data URL", "type": "text", "required": True,
         "placeholder": "http://192.168.0.100:5000/api/led"},
        {"name": "method", "label": "Method", "type": "text", "default": "GET"},
        {"name": "timeout", "label": "Timeout (s)", "type": "number", "default": 8},
        {"name": "fields", "label": "Metric → field map", "type": "keymap",
         "default": {"value": "value"}},
    ],
}


def read(cfg: dict) -> dict[str, float]:
    url = cfg.get("url")
    if not url:
        raise ValueError("http sensor needs a 'url'")
    method = (cfg.get("method") or "GET").upper()
    timeout = float(cfg.get("timeout", 8))
    fields = cfg.get("fields") or {}
    if not fields:
        raise ValueError("http sensor needs at least one metric→field mapping")

    with httpx.Client(timeout=timeout) as client:
        resp = client.request(method, url, headers={"Accept": "application/json"})
        resp.raise_for_status()
        payload = resp.json()

    out: dict[str, float] = {}
    for metric, path in fields.items():
        out[metric] = coerce_number(get_by_path(payload, path))
    return out
