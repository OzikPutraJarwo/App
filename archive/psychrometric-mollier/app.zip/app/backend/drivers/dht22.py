"""DHT22 / DHT11 temperature + humidity sensor (Raspberry Pi only).

Requires the adafruit-circuitpython-dht library on the Pi:
    pip install adafruit-circuitpython-dht
Returns tdb (°C), rh (%) and derived humidity ratio w.
"""
from __future__ import annotations

import math

INFO = {
    "key": "dht22",
    "label": "DHT22 / DHT11 (Pi)",
    "pi_only": True,
    "description": "Temperature + humidity on one GPIO pin. Needs adafruit-circuitpython-dht.",
    "fields": [
        {"name": "pin", "label": "BCM pin number", "type": "number", "required": True,
         "placeholder": "4"},
        {"name": "model", "label": "Model (dht22/dht11)", "type": "text", "default": "dht22"},
    ],
}

_devices: dict[int, object] = {}


def _humidity_ratio(tdb: float, rh: float, patm: float = 101325.0) -> float:
    pws = 610.94 * math.exp((17.625 * tdb) / (tdb + 243.04))
    pw = (rh / 100.0) * pws
    return 0.621945 * pw / (patm - pw)


def read(cfg: dict) -> dict[str, float]:
    import adafruit_dht  # deferred: Pi-only
    import board

    pin_num = int(cfg["pin"])
    if pin_num not in _devices:
        pin = getattr(board, f"D{pin_num}")
        model = (cfg.get("model") or "dht22").lower()
        cls = adafruit_dht.DHT11 if model == "dht11" else adafruit_dht.DHT22
        _devices[pin_num] = cls(pin)

    dev = _devices[pin_num]
    tdb = dev.temperature
    rh = dev.humidity
    if tdb is None or rh is None:
        raise RuntimeError("DHT read returned no data (retry next poll)")
    return {"tdb": round(tdb, 2), "rh": round(rh, 1), "w": round(_humidity_ratio(tdb, rh), 5)}
