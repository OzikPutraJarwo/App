"""DS18B20 1-Wire temperature probe (Raspberry Pi only).

Enable 1-Wire first: `sudo raspi-config` → Interface Options → 1-Wire, reboot.
The probe then appears under /sys/bus/w1/devices/28-*/w1_slave. Returns tdb (°C).
"""
from __future__ import annotations

import glob

INFO = {
    "key": "ds18b20",
    "label": "DS18B20 1-Wire temp (Pi)",
    "pi_only": True,
    "description": "Waterproof 1-Wire temperature probe. Enable 1-Wire in raspi-config first.",
    "fields": [
        {"name": "device_id", "label": "Device id (blank = first found)", "type": "text",
         "default": ""},
        {"name": "metric", "label": "Metric name", "type": "text", "default": "tdb"},
    ],
}


def _device_path(device_id: str) -> str:
    if device_id:
        return f"/sys/bus/w1/devices/{device_id}/w1_slave"
    matches = glob.glob("/sys/bus/w1/devices/28-*/w1_slave")
    if not matches:
        raise RuntimeError("no DS18B20 found (is 1-Wire enabled?)")
    return matches[0]


def read(cfg: dict) -> dict[str, float]:
    metric = cfg.get("metric") or "tdb"
    with open(_device_path(cfg.get("device_id", "")), "r", encoding="utf-8") as f:
        lines = f.readlines()
    if not lines or not lines[0].strip().endswith("YES"):
        raise RuntimeError("DS18B20 CRC not valid yet (retry next poll)")
    pos = lines[1].find("t=")
    if pos == -1:
        raise RuntimeError("DS18B20 gave no temperature")
    return {metric: round(int(lines[1][pos + 2:]) / 1000.0, 3)}
