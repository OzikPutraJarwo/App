"""Driver registry.

Add a new sensor type by dropping a module in this folder that defines INFO and
read(); then list it in _MODULES below. Everything else (UI, polling, storage)
picks it up automatically.
"""
from __future__ import annotations

from . import dht22, ds18b20, gpio_digital, http
from .base import is_raspberry_pi

_MODULES = [http, gpio_digital, dht22, ds18b20]

REGISTRY = {m.INFO["key"]: m for m in _MODULES}


def list_drivers() -> list[dict]:
    """Driver metadata for the UI, flagging Pi-only drivers as unavailable off-Pi."""
    on_pi = is_raspberry_pi()
    out = []
    for mod in _MODULES:
        info = dict(mod.INFO)
        info["available"] = (not info.get("pi_only")) or on_pi
        out.append(info)
    return out


def read(driver_key: str, cfg: dict) -> dict[str, float]:
    mod = REGISTRY.get(driver_key)
    if mod is None:
        raise ValueError(f"unknown driver '{driver_key}'")
    metrics = mod.read(cfg)
    if not metrics:
        raise ValueError("driver returned no metrics")
    return metrics
