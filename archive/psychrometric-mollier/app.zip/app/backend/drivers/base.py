"""Shared helpers for sensor drivers.

A driver is any module that defines:
  INFO  -> dict describing the driver (key, label, pi_only, description, fields)
  read(cfg: dict) -> dict[str, float]     # metric_name -> numeric value

`read` may raise; the poller catches it and marks the sensor as errored.
Numbers only — a metric value must be int/float (booleans are coerced to 0/1).
"""
from __future__ import annotations

from typing import Any


def get_by_path(obj: Any, path: str) -> Any:
    """Read a value from nested JSON using a dotted path, e.g. "data.temp"."""
    if not path:
        return obj
    cur = obj
    for key in path.split("."):
        if isinstance(cur, dict) and key in cur:
            cur = cur[key]
        else:
            raise KeyError(f"field path '{path}' not found (missing '{key}')")
    return cur


def coerce_number(value: Any) -> float:
    """Coerce a driver's raw value to a float, raising a clear error if not numeric."""
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value.strip())
        except ValueError:
            pass
    raise ValueError(f"value {value!r} is not numeric")


# Detect whether we're on a Raspberry Pi (so Pi-only drivers can be offered/hidden).
def is_raspberry_pi() -> bool:
    try:
        with open("/proc/device-tree/model", "r", encoding="utf-8", errors="ignore") as f:
            return "raspberry pi" in f.read().lower()
    except OSError:
        return False
