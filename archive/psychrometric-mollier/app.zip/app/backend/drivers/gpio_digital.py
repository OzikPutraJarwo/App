"""Digital GPIO input (Raspberry Pi only).

Reads a single pin as 0/1 — e.g. a motion sensor, a float switch, a button.
The gpiozero import is deferred to read() so this module loads fine on a PC.
"""
from __future__ import annotations

INFO = {
    "key": "gpio_digital",
    "label": "GPIO digital input (Pi)",
    "pi_only": True,
    "description": "Read one Raspberry Pi GPIO pin as on/off (1/0).",
    "fields": [
        {"name": "pin", "label": "BCM pin number", "type": "number", "required": True,
         "placeholder": "17"},
        {"name": "pull_up", "label": "Pull-up", "type": "bool", "default": False},
        {"name": "metric", "label": "Metric name", "type": "text", "default": "state"},
    ],
}

# Cache DigitalInputDevice objects so we don't re-acquire the pin every poll.
_devices: dict[int, object] = {}


def read(cfg: dict) -> dict[str, float]:
    from gpiozero import DigitalInputDevice  # deferred: Pi-only

    pin = int(cfg["pin"])
    metric = cfg.get("metric") or "state"
    if pin not in _devices:
        _devices[pin] = DigitalInputDevice(pin, pull_up=bool(cfg.get("pull_up", False)))
    return {metric: float(_devices[pin].value)}
