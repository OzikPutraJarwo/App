"""Stored-reading queries: history for charts/tables, CSV export, retention prune."""
from __future__ import annotations

import csv
import io
import time
from datetime import datetime, timezone

from . import db


def query(sensor_id: int | None = None, metric: str | None = None,
          since: float | None = None, until: float | None = None,
          limit: int = 5000) -> list[dict]:
    sql = "SELECT r.id, r.sensor_id, s.name AS sensor, r.ts, r.metric, r.value " \
          "FROM readings r LEFT JOIN sensors s ON s.id = r.sensor_id WHERE 1=1"
    params: list = []
    if sensor_id is not None:
        sql += " AND r.sensor_id=?"; params.append(sensor_id)
    if metric:
        sql += " AND r.metric=?"; params.append(metric)
    if since is not None:
        sql += " AND r.ts>=?"; params.append(since)
    if until is not None:
        sql += " AND r.ts<=?"; params.append(until)
    sql += " ORDER BY r.ts DESC LIMIT ?"; params.append(int(limit))
    rows = db.fetch_all(sql, params)
    for r in rows:
        r["timestamp"] = _iso(r["ts"])
    return rows


def metrics_for(sensor_id: int) -> list[str]:
    rows = db.fetch_all(
        "SELECT DISTINCT metric FROM readings WHERE sensor_id=? ORDER BY metric", (sensor_id,))
    return [r["metric"] for r in rows]


def to_csv(rows: list[dict]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["timestamp", "sensor_id", "sensor", "metric", "value"])
    for r in rows:
        writer.writerow([r.get("timestamp"), r.get("sensor_id"), r.get("sensor"),
                         r.get("metric"), r.get("value")])
    return buf.getvalue()


def stats() -> dict:
    row = db.fetch_one("SELECT COUNT(*) AS n, MIN(ts) AS first, MAX(ts) AS last FROM readings")
    per_sensor = db.fetch_all(
        "SELECT sensor_id, COUNT(*) AS n FROM readings GROUP BY sensor_id")
    return {"total": row["n"] if row else 0,
            "first": _iso(row["first"]) if row and row["first"] else None,
            "last": _iso(row["last"]) if row and row["last"] else None,
            "per_sensor": {r["sensor_id"]: r["n"] for r in per_sensor}}


def delete(sensor_id: int | None = None, before: float | None = None) -> int:
    sql, params = "DELETE FROM readings WHERE 1=1", []
    if sensor_id is not None:
        sql += " AND sensor_id=?"; params.append(sensor_id)
    if before is not None:
        sql += " AND ts<?"; params.append(before)
    return db.execute(sql, params)


def prune_old() -> None:
    days = float(db.get_setting("retention_days", 30))
    if days <= 0:
        return
    cutoff = time.time() - days * 86400
    n = delete(before=cutoff)
    if n:
        db.log_event("info", f"retention: pruned {n} readings older than {days} days", "history")


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
